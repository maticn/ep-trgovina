
package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "idIzdelek",
    "ime",
    "opis",
    "cena",
    "aktivno",
    "avg_ocena",
    "count_ocena",
    "slike"
})
public class Izdelki {

    @JsonProperty("idIzdelek")
    private String idIzdelek;
    @JsonProperty("ime")
    private String ime;
    @JsonProperty("opis")
    private String opis;
    @JsonProperty("cena")
    private String cena;
    @JsonProperty("aktivno")
    private String aktivno;
    @JsonProperty("avg_ocena")
    private Object avgOcena;
    @JsonProperty("count_ocena")
    private String countOcena;
    @JsonProperty("slike")
    private List<Object> slike = new ArrayList<Object>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Izdelki() {
    }

    /**
     * 
     * @param avgOcena
     * @param slike
     * @param aktivno
     * @param idIzdelek
     * @param countOcena
     * @param opis
     * @param ime
     * @param cena
     */
    public Izdelki(String idIzdelek, String ime, String opis, String cena, String aktivno, Object avgOcena, String countOcena, List<Object> slike) {
        this.idIzdelek = idIzdelek;
        this.ime = ime;
        this.opis = opis;
        this.cena = cena;
        this.aktivno = aktivno;
        this.avgOcena = avgOcena;
        this.countOcena = countOcena;
        this.slike = slike;
    }

    /**
     * 
     * @return
     *     The idIzdelek
     */
    @JsonProperty("idIzdelek")
    public String getIdIzdelek() {
        return idIzdelek;
    }

    /**
     * 
     * @param idIzdelek
     *     The idIzdelek
     */
    @JsonProperty("idIzdelek")
    public void setIdIzdelek(String idIzdelek) {
        this.idIzdelek = idIzdelek;
    }

    /**
     * 
     * @return
     *     The ime
     */
    @JsonProperty("ime")
    public String getIme() {
        return ime;
    }

    /**
     * 
     * @param ime
     *     The ime
     */
    @JsonProperty("ime")
    public void setIme(String ime) {
        this.ime = ime;
    }

    /**
     * 
     * @return
     *     The opis
     */
    @JsonProperty("opis")
    public String getOpis() {
        return opis;
    }

    /**
     * 
     * @param opis
     *     The opis
     */
    @JsonProperty("opis")
    public void setOpis(String opis) {
        this.opis = opis;
    }

    /**
     * 
     * @return
     *     The cena
     */
    @JsonProperty("cena")
    public String getCena() {
        return cena;
    }

    /**
     * 
     * @param cena
     *     The cena
     */
    @JsonProperty("cena")
    public void setCena(String cena) {
        this.cena = cena;
    }

    /**
     * 
     * @return
     *     The aktivno
     */
    @JsonProperty("aktivno")
    public String getAktivno() {
        return aktivno;
    }

    /**
     * 
     * @param aktivno
     *     The aktivno
     */
    @JsonProperty("aktivno")
    public void setAktivno(String aktivno) {
        this.aktivno = aktivno;
    }

    /**
     * 
     * @return
     *     The avgOcena
     */
    @JsonProperty("avg_ocena")
    public Object getAvgOcena() {
        return avgOcena;
    }

    /**
     * 
     * @param avgOcena
     *     The avg_ocena
     */
    @JsonProperty("avg_ocena")
    public void setAvgOcena(Object avgOcena) {
        this.avgOcena = avgOcena;
    }

    /**
     * 
     * @return
     *     The countOcena
     */
    @JsonProperty("count_ocena")
    public String getCountOcena() {
        return countOcena;
    }

    /**
     * 
     * @param countOcena
     *     The count_ocena
     */
    @JsonProperty("count_ocena")
    public void setCountOcena(String countOcena) {
        this.countOcena = countOcena;
    }

    /**
     * 
     * @return
     *     The slike
     */
    @JsonProperty("slike")
    public List<Object> getSlike() {
        return slike;
    }

    /**
     * 
     * @param slike
     *     The slike
     */
    @JsonProperty("slike")
    public void setSlike(List<Object> slike) {
        this.slike = slike;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
